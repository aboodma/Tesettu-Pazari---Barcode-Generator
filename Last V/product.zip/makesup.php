<form class="" action="subproduct.php" method="post">
  <p>MainProductCode</p>
  <input type="text" name="MainProductCode" value="">
  <br>
  <p>SubProductCode</p>
  <input type="text" name="SubProductCode" value="">
  <br>
  <p>Property2</p>
  <input type="text" name="Property2" value="">
  <br>
  <p>Barcode</p>
  <input type="text" name="Barcode" value="">
  <br>
  <input type="submit" name="submit" value="send">

</form>
