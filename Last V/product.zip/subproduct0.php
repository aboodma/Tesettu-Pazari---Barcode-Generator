<?php
print_r($_POST);
// if (isset($_POST['MainProductCode'])) {
//   // code...
// $MainProductCode=$_POST['MainProductCode'];
// $SubProductCode=$_POST['SubProductCode'];
// $Barcode=$_POST['Barcode'];
// $Property2=$_POST['Property2'];
// $url = "http://tesetturpazari.com/rest1/subProduct/addSubProducts";
//
// $fields = array( 'token' => '5m64ek2v9q63bh7fq9sihn5tc2',
//                   'data'=>'[
//                               {
//                                   "MainProductCode": "'.$MainProductCode.'",
//                                   "SubProductCode": "'.$SubProductCode.'",
//                                   "Barcode": "'.$Barcode.'",
//                                   "SupplierSubProductCode": "",
//                                   "Property1GroupId": "",
//                                   "Property2GroupId": "",
//                                   "Property1": "",
//                                   "Property2": "'.$Property2.'",
//                                   "BuyingPrice": "200",
//                                   "SellingPrice": "350",
//                                   "VendorSellingPrice": "380",
//                                   "Stock": "35",
//                                   "CBM": "30",
//                                   "IsActive": "1"
//                               }
//                           ]');
//
// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, $url);
// curl_setopt($ch, CURLOPT_POST, 1);
// curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//
// $response = curl_exec($ch);
// curl_close($ch);
//
// print_r($response);
//
// }
  ?>
